using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class statDisplayShop : MonoBehaviour
{
    public stats stats;
    public Text[] statText;

    // Start is called before the first frame update
    void Start()
    {
        stats = Object.FindObjectOfType<stats>();

        UpdateStatDisplay();
    }

    // Update is called once per frame
    void Update()
    {
        UpdateStatDisplay();
    }

    private int GetStatValue(string statName)
    {
        switch (statName)
        {
            case "piercing": return stats.piercing;
            case "radius": return stats.radius;
            case "pieces": return stats.pieces;
            case "boxes": return stats.boxes;
            default: return 0;
        }
    }

    private void UpdateStatDisplay()
    {
        if (statText.Length >= 4)
        {
            // Update each stat text with its corresponding value
            statText[0].text = "Pieces: " + GetStatValue("pieces").ToString();
            statText[1].text = "Radius: " + GetStatValue("radius").ToString();
            statText[2].text = "Piercing: " + GetStatValue("piercing").ToString();
            statText[3].text = "Boxes: " + GetStatValue("boxes").ToString();
        }
    }
}
