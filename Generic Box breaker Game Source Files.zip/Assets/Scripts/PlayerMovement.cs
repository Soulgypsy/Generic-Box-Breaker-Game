using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 7f;
    public float maxVelocity = 10f;
    public float mouseSensitivity = 2f;
    public GameObject bulletPrefab;
    public Transform shootPoint;
    public float bulletSpeed = 20f;

    private Rigidbody rb;
    private Vector3 moveInput;
    private float rotationX = 0f;
    public Transform cameraTransform;
    public Shop shop;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        if (shop.gameObject.activeSelf == true)
        {
            Cursor.lockState = CursorLockMode.None;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
             // Mouse Look
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        rotationX -= mouseY;
        rotationX = Mathf.Clamp(rotationX, -90f, 90f);

        cameraTransform.localRotation = Quaternion.Euler(rotationX, 0, 0);
        transform.Rotate(Vector3.up * mouseX);

       

        // Jumping
        if (Input.GetKeyDown(KeyCode.Space) && IsGrounded())
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }

        // Shooting
        if (Input.GetMouseButtonDown(0))
        {
            Shoot();
        }
        }

        // Movement Input
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");
        Vector3 moveDirection = transform.right * moveX + transform.forward * moveZ;
        moveInput = moveDirection.normalized * moveSpeed;
    }

    void FixedUpdate()
    {
        Vector3 velocity = rb.velocity;
        Vector3 targetVelocity = new Vector3(moveInput.x, velocity.y, moveInput.z);
        rb.velocity = Vector3.ClampMagnitude(targetVelocity, maxVelocity);
    }

    void Shoot()
    {
        if (bulletPrefab != null && shootPoint != null)
        {
            Debug.Log("Shooting at position: " + shootPoint.position + " with rotation: " + shootPoint.rotation);
            GameObject bullet = Instantiate(bulletPrefab, shootPoint.position, shootPoint.rotation);
            Rigidbody bulletRb = bullet.GetComponent<Rigidbody>();
            if (bulletRb != null)
            {
                bulletRb.velocity = shootPoint.forward * bulletSpeed;
            }
        }
        else
        {
            Debug.Log("Bullet prefab or shoot point is missing!");
        }
    }

    bool IsGrounded()
    {
        return Physics.Raycast(transform.position, Vector3.down, 1.1f);
    }
}
