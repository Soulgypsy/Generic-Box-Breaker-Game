using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shopEnable : MonoBehaviour
{
    [SerializeField] private GameObject targetObject;  // The object to enable/disable

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))  // Ensure it reacts only to the player
        {
            targetObject.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            targetObject.SetActive(false);
        }
    }
}
