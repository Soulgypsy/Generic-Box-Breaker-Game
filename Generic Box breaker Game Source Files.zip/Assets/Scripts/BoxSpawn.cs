using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxSpawn : MonoBehaviour
{
    public GameObject objectPrefab;
    public stats boxAmount;
    public Vector3 spawnRange = new Vector3(5f, 0f, 5f); // Range around the spawner

    private List<GameObject> spawnedObjects = new List<GameObject>();

    void Start()
    {
        SpawnObjects();
    }

    void SpawnObjects()
    {
        ClearObjects();

        for (int i = 0; i < boxAmount.boxes; i++)
        {
            print(i);
            Vector3 randomPos = new Vector3(
                Random.Range(-spawnRange.x, spawnRange.x),
                Random.Range(-spawnRange.y, spawnRange.y),
                Random.Range(-spawnRange.z, spawnRange.z)
            );

            Vector3 spawnPosition = transform.position + randomPos;
            GameObject newObj = Instantiate(objectPrefab, spawnPosition, Quaternion.identity);
            spawnedObjects.Add(newObj);
        }
    }

    public void RespawnObjects()
    {
        SpawnObjects();
    }

    void ClearObjects()
    {
        foreach (var obj in spawnedObjects)
        {
            if (obj != null)
            {
                Destroy(obj);
            }
        }
        spawnedObjects.Clear();
    }
}
