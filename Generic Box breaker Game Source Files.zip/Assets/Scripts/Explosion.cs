using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour
{
    public stats stats;
    public float explosionRadius;
    public float explosionForce = 700f;

    public GameObject radiusVisualPrefab; // Transparent sphere prefab
    private GameObject radiusVisualInstance;

    private void Start()
    {
        stats = Object.FindObjectOfType<stats>();
        explosionRadius = stats.radius;

        if (radiusVisualPrefab != null)
        {
            radiusVisualInstance = Instantiate(radiusVisualPrefab, transform.position, Quaternion.identity, transform);
            float scale = explosionRadius * 2f; // Diameter, not radius
            radiusVisualInstance.transform.localScale = new Vector3(scale, scale, scale);
        }
    }

    void OnTriggerEnter(Collider collision)
    {
        if (collision.tag == "destructible")
        {
            radiusVisualInstance.SetActive(true);
            Explode();
        }
    }

    void Explode()
    {
        // Find nearby objects
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
        foreach (Collider nearbyObject in colliders)
        {
            // Apply force if it has a Rigidbody
            Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            }
        }
        StartCoroutine(WaitAndDestroyVisual());
    }

    IEnumerator WaitAndDestroyVisual()
    {
        yield return new WaitForSeconds(1f);

        if (radiusVisualInstance != null)
        {
            Destroy(radiusVisualInstance);
        }


        Destroy(gameObject);
    }
}
