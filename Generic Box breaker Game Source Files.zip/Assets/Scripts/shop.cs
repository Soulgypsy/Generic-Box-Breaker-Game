using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Shop : MonoBehaviour
{
    [System.Serializable]
    public class StatUI
    {
        public string statName;         // Name of the stat
        public Text statText;           // Display stat value
        public Text priceText;          // Display stat price
    }

    public Text moneyAmountText;

    public StatUI[] statUIs;             // Array to hold all stat UI elements
    public int statIncrease = 1;             // How much stat increases per purchase
    public float priceMultiplier = 1.5f;     // Price increase factor

    public stats statScript;                 // Reference to stats script

    private Dictionary<string, int> statPrices = new Dictionary<string, int>();

    void Start()
    {
        // Initialize prices for each stat
        statPrices["piercing"] = 2;
        statPrices["radius"] = 3;
        statPrices["pieces"] = 5;
        statPrices["boxes"] = 10;
        statPrices["victory"] = 1000;

        UpdateUI("piercing");
        UpdateUI("radius");
        UpdateUI("pieces");
        UpdateUI("boxes");
        UpdateUI("victory");
    }

    private void Update()
    {
        moneyAmountText.text = statScript.cash + "$";
    }

    // Called when any stat button is clicked
    public void PurchaseItem(string statName)
    {
        if (!statPrices.ContainsKey(statName))
        {
            Debug.LogWarning($"Stat '{statName}' not found!");
            return;
        }

        int price = statPrices[statName];

        if (statScript.cash >= price)
        {
            statScript.cash -= price;

            // Increase the correct stat
            switch (statName)
            {
                case "piercing":
                    statScript.piercing += statIncrease;
                    break;
                case "radius":
                    statScript.radius += statIncrease;
                    break;
                case "pieces":
                    statScript.pieces += statIncrease;
                    break;
                case "boxes":
                    statScript.boxes += statIncrease;
                    break;
                case "victory":
                    Application.Quit();
                    break;
            }

            // Increase the price
            statPrices[statName] = Mathf.RoundToInt(price * priceMultiplier);

            UpdateUI(statName);
            Debug.Log($"Purchased {statName}! New Price: {statPrices[statName]}, Money Left: {statScript.cash}");
        }
        else
        {
            Debug.Log("Not enough money!");
        }
    }

    private void UpdateUI(string statName)
    {
        foreach (var statUI in statUIs)
        {
            if (statUI.statName == statName)
            {
                statUI.priceText.text = $"Price: ${statPrices[statName]}";
                moneyAmountText.text = statScript.cash + "$";
                return;
            }
        }
    }

    private int GetStatValue(string statName)
    {
        switch (statName)
        {
            case "piercing": return statScript.piercing;
            case "radius": return statScript.radius;
            case "pieces": return statScript.pieces;
            case "boxes": return statScript.boxes;
            default: return 0;
        }
    }
}
