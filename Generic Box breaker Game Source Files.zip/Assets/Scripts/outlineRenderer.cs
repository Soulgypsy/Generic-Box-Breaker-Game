using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class outlineRenderer : MonoBehaviour
{
    public Color outlineColor = Color.red;
    public float outlineWidth = 0.1f;

    private Renderer rend;
    private Material outlineMaterial;

    void Start()
    {
        rend = GetComponent<Renderer>();

        // Add outline material
        outlineMaterial = new Material(Shader.Find("Outlined/Uniform"));
        outlineMaterial.SetColor("_OutlineColor", outlineColor);
        outlineMaterial.SetFloat("_Outline", outlineWidth);

        rend.materials = new Material[] { rend.material, outlineMaterial };
    }
}
