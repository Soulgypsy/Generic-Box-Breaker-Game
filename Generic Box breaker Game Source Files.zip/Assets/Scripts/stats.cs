using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using UnityEngine;

public class stats : MonoBehaviour
{
    public int radius;
    public int piercing;
    public int cash;
    public int pieces;
    public int boxes;

    void Awake()
    {
        radius = 1;
        piercing = 0;
        cash = 0;
        pieces = 5;
        boxes = 1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
