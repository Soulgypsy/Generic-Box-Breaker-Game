using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FractureScript : MonoBehaviour
{
    public int fractureCount;  // number of pieces to break into
    public float explosionForce = 300f; // how much force is applied to the pieces
    public float explosionRadius = 2f; // how big the explosion is

    public stats stats;
    private Mesh originalMesh;

    void Start()
    {
        stats = GameObject.Find("Player").GetComponent<stats>();
        originalMesh = GetComponent<MeshFilter>().mesh; // gets the meshfilter. obviously.
        fractureCount = stats.pieces;
    }

    public void Fracture()
    {
        if (originalMesh == null) return;

        // create fracture pieces
        List<GameObject> fragments = VoronoiFracture(fractureCount);

        // apply physics force to each fragment
        foreach (var fragment in fragments)
        {
            Rigidbody rb = fragment.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            }
        }

        // destroy original object so it doesn't eat the fractals
        Destroy(gameObject);
    }

    List<GameObject> VoronoiFracture(int numPieces)
    {
        List<GameObject> pieces = new List<GameObject>();

        for (int i = 0; i < numPieces; i++)
        {
            GameObject piece = new GameObject("Fragment_" + i);
            piece.transform.position = transform.position;
            piece.transform.rotation = transform.rotation;

            // Copy mesh
            MeshFilter mf = piece.AddComponent<MeshFilter>();
            MeshRenderer mr = piece.AddComponent<MeshRenderer>();
            Rigidbody rb = piece.AddComponent<Rigidbody>();
            MeshCollider collider = piece.AddComponent<MeshCollider>();

            ParticleSystem ps = piece.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.startSize = 0.1f;          
            main.startSpeed = 0.5f;         
            main.startLifetime = 1f;      
            main.maxParticles = 20;         
            ps.Play();

            piece.AddComponent<Collection>();

            mf.mesh = GenerateRandomMeshPiece(originalMesh, i, numPieces);
            mr.material = GetComponent<MeshRenderer>().material; // Copy material

            // Setup Collider
            collider.sharedMesh = mf.mesh;
            collider.convex = true; // Make it physics-compatible

            pieces.Add(piece);
        }

        return pieces;
    }

    Mesh GenerateRandomMeshPiece(Mesh originalMesh, int index, int totalPieces)
    {
        Mesh newMesh = new Mesh();

        // slices the mesh into new vertices and puts them in lists
        Vector3[] vertices = originalMesh.vertices;
        int[] triangles = originalMesh.triangles;

        List<Vector3> newVertices = new List<Vector3>();
        List<int> newTriangles = new List<int>();

        for (int i = 0; i < triangles.Length; i += 3) // for each triangle in the list it adds the vertices to them on each side
        {
            if (i % totalPieces == index)
            {
                newTriangles.Add(newVertices.Count);
                newVertices.Add(vertices[triangles[i]]);

                newTriangles.Add(newVertices.Count);
                newVertices.Add(vertices[triangles[i + 1]]);

                newTriangles.Add(newVertices.Count);
                newVertices.Add(vertices[triangles[i + 2]]);
            }
        }

        // adds these new meshes to the array and applies them after calculating their normals
        newMesh.vertices = newVertices.ToArray();
        newMesh.triangles = newTriangles.ToArray();
        newMesh.RecalculateNormals();

        return newMesh;
    }
}
