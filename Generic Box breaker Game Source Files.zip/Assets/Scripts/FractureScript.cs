using System.Collections.Generic;
using UnityEngine;

public class FractureScript : MonoBehaviour
{
    public int fractureCount;  // number of pieces to break into
    public float explosionForce = 300f; // how much force is applied to the pieces
    public float explosionRadius = 2f; // how big the explosion is
    public float spawnHeight = 2f;  // Height above the ground to spawn pieces

    public stats stats;
    private Mesh originalMesh;

    void Start()
    {
        stats = GameObject.Find("Player").GetComponent<stats>();
        originalMesh = GetComponent<MeshFilter>().mesh; // gets the meshfilter. obviously.
        fractureCount = stats.pieces;
    }

    public void Fracture()
    {
        if (originalMesh == null) return;

        // create fracture pieces
        List<GameObject> fragments = VoronoiFracture(fractureCount);

        // apply physics force to each fragment
        foreach (var fragment in fragments)
        {
            Rigidbody rb = fragment.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            }
        }

        // destroy original object so it doesn't eat the fractals
        Destroy(gameObject);
    }

    List<GameObject> VoronoiFracture(int numPieces)
    {
        List<GameObject> pieces = new List<GameObject>();

        for (int i = 0; i < numPieces; i++)
        {
            GameObject piece = new GameObject("Fragment_" + i);

            // Find spawn position above the ground
            Vector3 spawnPosition = GetSpawnPosition();

            piece.transform.position = spawnPosition;
            piece.transform.rotation = transform.rotation;

            // Copy mesh
            MeshFilter mf = piece.AddComponent<MeshFilter>();
            MeshRenderer mr = piece.AddComponent<MeshRenderer>();
            Rigidbody rb = piece.AddComponent<Rigidbody>();
            MeshCollider collider = piece.AddComponent<MeshCollider>();

            ParticleSystem ps = piece.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.startSize = 0.1f;
            main.startSpeed = 0.5f;
            main.startLifetime = 1f;
            main.maxParticles = 20;
            ps.Play();

            piece.AddComponent<Collection>();

            mf.mesh = GenerateRandomMeshPiece(originalMesh, i, numPieces);
            mr.material = GetComponent<MeshRenderer>().material; // Copy material

            // Setup Collider
            collider.sharedMesh = mf.mesh;
            collider.convex = true; // Make it physics-compatible

            pieces.Add(piece);
        }

        return pieces;
    }

    // Function to get a spawn position above the floor
    Vector3 GetSpawnPosition()
    {
        Vector3 spawnPosition = transform.position;

        // Check for the ground by casting a ray downwards
        RaycastHit hit;
        if (Physics.Raycast(spawnPosition, Vector3.down, out hit, Mathf.Infinity))
        {
            // Make sure the spawn position is above the hit point (floor)
            spawnPosition.y = hit.point.y + spawnHeight;
        }
        else
        {
            // If there's no hit, just spawn at a default height
            spawnPosition.y = transform.position.y + spawnHeight;
        }

        return spawnPosition;
    }

    Mesh GenerateRandomMeshPiece(Mesh originalMesh, int index, int totalPieces)
    {
        Mesh newMesh = new Mesh();

        // slices the mesh into new vertices and puts them in lists
        Vector3[] vertices = originalMesh.vertices;
        int[] triangles = originalMesh.triangles;

        List<Vector3> newVertices = new List<Vector3>();
        List<int> newTriangles = new List<int>();

        // To ensure that each fragment gets a fair amount of triangles
        int trianglesPerPiece = triangles.Length / totalPieces;

        for (int i = index * trianglesPerPiece; i < (index + 1) * trianglesPerPiece && i + 2 < triangles.Length; i += 3) // For each triangle in the chunk
        {
            newTriangles.Add(newVertices.Count);
            newVertices.Add(vertices[triangles[i]]);

            newTriangles.Add(newVertices.Count);
            newVertices.Add(vertices[triangles[i + 1]]);

            newTriangles.Add(newVertices.Count);
            newVertices.Add(vertices[triangles[i + 2]]);
        }

        // adds these new meshes to the array and applies them after calculating their normals
        newMesh.vertices = newVertices.ToArray();
        newMesh.triangles = newTriangles.ToArray();
        newMesh.RecalculateNormals();

        return newMesh;
    }
}
